var f1 = function(){
	alert("Hello world of javascript");
}